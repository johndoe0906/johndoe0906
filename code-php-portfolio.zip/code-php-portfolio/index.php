<!DOCTYPE html>
<html lang="ja">
  <body>
  <h1>ようこそ！私のポートフォリオへ</h1>
  <link rel="stylesheet" href="css/styles.css">
    <header>
      <nav>
        <ul>
        <h1><a href="index.php">ホーム</a></h1>
        <h1><a href="about.php">自己紹介</a></h1>
        <h1><a href="works.php">経歴</a></h1>
        <h1><a href="contact.php">目標</a></h1>
        </ul>
      </nav>
    </header>
</body>
</html>