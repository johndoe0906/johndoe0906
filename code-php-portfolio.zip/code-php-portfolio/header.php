<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <title>ポートフォリオ</title>
  <link rel="stylesheet" href="/css/style.css">
</head>
<body>
  <header>
    <nav>
      <a href="index.php">ホーム</a>
      <a href="about.php">自己紹介</a>
      <a href="works.php">経歴</a>
      <a href="contact.php">目標</a>
    </nav>
  </header>