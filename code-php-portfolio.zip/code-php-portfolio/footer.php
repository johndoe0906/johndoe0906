<footer>
    <p>&copy; <?php echo date("Y"); ?> 山川友樹のポートフォリオ</p>
  </footer>
</body>
</html>